package com.example.hamsterpet.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.core.graphics.ColorUtils

/** Рисует хомяка кодом (без PNG): ноль битмапов в памяти. */
object HamsterPainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val DARK = 0xFF4E342E.toInt()
    private val PINK = 0xFFFF8A80.toInt()

    private fun disc(c: Canvas, x: Float, y: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(x, y, rad, p)
    }

    private fun oval(c: Canvas, l: Float, t: Float, rt: Float, b: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        r.set(l, t, rt, b)
        c.drawOval(r, p)
    }

    private fun line(w: Float, color: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND; p.color = color
    }

    fun draw(
        c: Canvas, s: Float, color: Int, hat: Int, glasses: Int,
        happy: Boolean, sleeping: Boolean, frame: Int, faceRight: Boolean
    ) {
        if (s <= 0f) return
        val dark = ColorUtils.blendARGB(color, Color.BLACK, 0.25f)
        val light = ColorUtils.blendARGB(color, Color.WHITE, 0.5f)
        c.save()
        if (!faceRight) c.scale(-1f, 1f, s / 2f, s / 2f)

        // тень и лапки
        oval(c, .18f * s, .90f * s, .82f * s, .99f * s, 0x22000000)
        val dx = if (frame == 0) -.03f * s else .03f * s
        oval(c, .22f * s + dx, .86f * s, .38f * s + dx, .96f * s, dark)
        oval(c, .62f * s - dx, .86f * s, .78f * s - dx, .96f * s, dark)
        // уши
        disc(c, .27f * s, .17f * s, .09f * s, color); disc(c, .27f * s, .17f * s, .05f * s, PINK)
        disc(c, .73f * s, .17f * s, .09f * s, color); disc(c, .73f * s, .17f * s, .05f * s, PINK)
        // тело, пузико, голова, щёки
        oval(c, .14f * s, .38f * s, .86f * s, .92f * s, color)
        oval(c, .30f * s, .56f * s, .70f * s, .91f * s, light)
        disc(c, .5f * s, .42f * s, .30f * s, color)
        disc(c, .30f * s, .52f * s, .06f * s, 0x55FF5252)
        disc(c, .70f * s, .52f * s, .06f * s, 0x55FF5252)
        // глаза
        if (sleeping) {
            line(.015f * s, DARK)
            r.set(.33f * s, .36f * s, .43f * s, .44f * s); c.drawArc(r, 0f, 180f, false, p)
            r.set(.57f * s, .36f * s, .67f * s, .44f * s); c.drawArc(r, 0f, 180f, false, p)
        } else {
            disc(c, .38f * s, .40f * s, .035f * s, DARK)
            disc(c, .62f * s, .40f * s, .035f * s, DARK)
            disc(c, .39f * s, .39f * s, .012f * s, Color.WHITE)
            disc(c, .63f * s, .39f * s, .012f * s, Color.WHITE)
        }
        // нос и рот
        disc(c, .5f * s, .48f * s, .03f * s, 0xFFE57373.toInt())
        line(.012f * s, DARK)
        if (happy || sleeping) {
            r.set(.44f * s, .49f * s, .56f * s, .58f * s); c.drawArc(r, 0f, 180f, false, p)
        } else {
            r.set(.44f * s, .56f * s, .56f * s, .64f * s); c.drawArc(r, 180f, 180f, false, p)
        }
        // очки
        when (glasses) {
            1 -> {
                line(.014f * s, DARK)
                c.drawCircle(.38f * s, .40f * s, .085f * s, p)
                c.drawCircle(.62f * s, .40f * s, .085f * s, p)
                c.drawLine(.465f * s, .40f * s, .535f * s, .40f * s, p)
            }
            2 -> {
                p.style = Paint.Style.FILL; p.color = 0xE6212121.toInt()
                r.set(.28f * s, .34f * s, .47f * s, .46f * s); c.drawRoundRect(r, .03f * s, .03f * s, p)
                r.set(.53f * s, .34f * s, .72f * s, .46f * s); c.drawRoundRect(r, .03f * s, .03f * s, p)
                line(.014f * s, 0xFF212121.toInt())
                c.drawLine(.47f * s, .38f * s, .53f * s, .38f * s, p)
            }
        }
        // шляпы
        when (hat) {
            1 -> {
                p.style = Paint.Style.FILL; p.color = 0xFFE53935.toInt()
                r.set(.22f * s, .02f * s, .78f * s, .40f * s); c.drawArc(r, 180f, 180f, true, p)
                r.set(.46f * s, .17f * s, .90f * s, .23f * s); c.drawRoundRect(r, .03f * s, .03f * s, p)
            }
            2 -> {
                path.reset()
                path.moveTo(.5f * s, 0f); path.lineTo(.33f * s, .18f * s); path.lineTo(.67f * s, .18f * s); path.close()
                p.style = Paint.Style.FILL; p.color = 0xFF7E57C2.toInt()
                c.drawPath(path, p)
                disc(c, .5f * s, .02f * s, .03f * s, 0xFFFFD54F.toInt())
            }
            3 -> {
                path.reset()
                path.moveTo(.30f * s, .18f * s); path.lineTo(.30f * s, .04f * s); path.lineTo(.40f * s, .11f * s)
                path.lineTo(.50f * s, .02f * s); path.lineTo(.60f * s, .11f * s); path.lineTo(.70f * s, .04f * s)
                path.lineTo(.70f * s, .18f * s); path.close()
                p.style = Paint.Style.FILL; p.color = 0xFFFFC107.toInt()
                c.drawPath(path, p)
            }
        }
        c.restore()

        if (sleeping) {
            p.style = Paint.Style.FILL; p.color = 0xFF5C6BC0.toInt()
            p.textSize = .2f * s; p.isFakeBoldText = true
            c.drawText("z", .76f * s, .22f * s, p)
        }
    }
}
