package com.example.hamsterpet.overlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.hamsterpet.data.HamsterRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = HamsterRepository(c).load() ?: return
        if (s.overlayOn && Settings.canDrawOverlays(c)) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
