package com.example.hamsterpet

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.hamsterpet.data.HamsterState
import com.example.hamsterpet.data.Look
import com.example.hamsterpet.overlay.OverlayService
import com.example.hamsterpet.ui.Emui
import com.example.hamsterpet.ui.HamsterView
import com.example.hamsterpet.ui.HamsterViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var vm: HamsterViewModel
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            vm.refresh()
            handler.postDelayed(this, 10_000)
        }
    }
    private var mode = 0 // 1 = создание, 2 = питомец
    private var pickedColor = Look.COLORS[0]
    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startOverlay() }

    private lateinit var hv: HamsterView
    private lateinit var nameTv: TextView
    private lateinit var cloneTv: TextView
    private lateinit var btnClone: Button
    private lateinit var btnOverlay: Button
    private lateinit var barHunger: ProgressBar
    private lateinit var barThirst: ProgressBar
    private lateinit var barMood: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm = ViewModelProvider(this)[HamsterViewModel::class.java]
        vm.state.observe(this) { render(it) }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun render(s: HamsterState?) {
        if (s == null) {
            if (mode != 1) showCreate()
        } else {
            if (mode != 2) showPet()
            bind(s)
        }
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun label(t: String, sp: Float = 16f) = TextView(this).apply {
        text = t; textSize = sp; gravity = Gravity.CENTER
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun page() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(24), dp(16), dp(16))
    }

    private fun bar(title: String, color: Int): Pair<View, ProgressBar> {
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(color)
        }
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            addView(
                TextView(this@MainActivity).apply { text = title; textSize = 15f },
                LinearLayout.LayoutParams(dp(90), LinearLayout.LayoutParams.WRAP_CONTENT)
            )
            addView(pb, LinearLayout.LayoutParams(0, dp(12), 1f))
        }
        return r to pb
    }

    // ---------- экран создания ----------
    private fun showCreate() {
        mode = 1
        val p = page()
        p.addView(label("Создай хомяка", 24f))
        val preview = HamsterView(this).apply { set(pickedColor, 0, 0, true) }
        p.addView(preview, LinearLayout.LayoutParams(dp(180), dp(180)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(12); bottomMargin = dp(12)
        })
        val name = EditText(this).apply {
            hint = "Имя хомяка"; setSingleLine()
            filters = arrayOf(InputFilter.LengthFilter(16))
        }
        p.addView(name)
        p.addView(label("Цвет шерсти"))
        val colors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL
        }
        Look.COLORS.forEach { c ->
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(2), 0x55000000)
                }
                setOnClickListener { pickedColor = c; preview.set(c, 0, 0, true) }
            }
            colors.addView(dot, LinearLayout.LayoutParams(dp(44), dp(44)).apply {
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        p.addView(colors)
        p.addView(btn("Создать хомяка") { vm.create(name.text.toString(), pickedColor) })
        setContentView(ScrollView(this).apply { addView(p) })
    }

    // ---------- экран питомца ----------
    private fun showPet() {
        mode = 2
        val p = page()
        nameTv = label("", 24f)
        hv = HamsterView(this)
        p.addView(nameTv)
        p.addView(hv, LinearLayout.LayoutParams(dp(200), dp(200)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8); bottomMargin = dp(8)
        })
        val (r1, b1) = bar("Голод", 0xFFFF9800.toInt())
        val (r2, b2) = bar("Жажда", 0xFF29B6F6.toInt())
        val (r3, b3) = bar("Настроение", 0xFFEC407A.toInt())
        barHunger = b1; barThirst = b2; barMood = b3
        p.addView(r1); p.addView(r2); p.addView(r3)

        p.addView(row(
            btn("Покормить") { vm.feed() },
            btn("Напоить") { vm.water() },
            btn("Играть") { if (!vm.play()) toast("Хомяк слишком голоден или хочет пить") }
        ))
        p.addView(btn("Сменить одежду") { clothes() })

        cloneTv = label("", 13f)
        p.addView(cloneTv)
        btnClone = btn("Создать клона") { vm.createClone(); syncOverlay() }
        p.addView(row(btnClone, btn("Удалить клона") { vm.deleteClones(); syncOverlay() }))

        btnOverlay = btn("") { toggleOverlay() }
        p.addView(btnOverlay)
        p.addView(btn("Настройки EMUI (автозапуск, батарея)") { emuiDialog() })
        p.addView(btn("Удалить хомяка") { confirmDelete() })
        setContentView(ScrollView(this).apply { addView(p) })
    }

    private fun bind(s: HamsterState) {
        nameTv.text = s.name
        hv.set(s.color, s.hat, s.glasses, s.mood >= 40f)
        barHunger.progress = s.hunger.toInt()
        barThirst.progress = s.thirst.toInt()
        barMood.progress = s.mood.toInt()
        cloneTv.text = "Клонов: ${s.clones}/${HamsterState.MAX_CLONES} (видны только на рабочем столе)\n" +
            "Клон доступен, когда голод, жажда и настроение ≥ 70"
        btnClone.isEnabled = s.canClone
        btnOverlay.text =
            if (s.overlayOn) "Вернуть хомяка в приложение" else "Выпустить хомяка на рабочий стол"
    }

    // ---------- диалоги ----------
    private fun clothes() {
        AlertDialog.Builder(this).setTitle("Сменить одежду")
            .setItems(arrayOf("Шляпа", "Очки")) { _, w ->
                if (w == 0) pick("Шляпа", Look.HATS) { vm.setHat(it); syncOverlay() }
                else pick("Очки", Look.GLASSES) { vm.setGlasses(it); syncOverlay() }
            }.show()
    }

    private fun pick(title: String, items: Array<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(items) { _, i -> onPick(i) }.show()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("Удалить хомяка?")
            .setMessage("Весь прогресс и все клоны будут удалены.")
            .setPositiveButton("Удалить") { _, _ ->
                stopService(Intent(this, OverlayService::class.java))
                vm.deleteHamster()
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun emuiDialog() {
        AlertDialog.Builder(this).setTitle("EMUI: чтобы хомяка не убивали")
            .setMessage(
                "1. Автозапуск: разреши автозапуск, вторичный запуск и работу в фоне.\n" +
                    "2. Батарея: выбери «Не ограничивать» (отключи оптимизацию).\n" +
                    "3. В списке недавних приложений потяни карточку приложения вниз (замок).\n" +
                    "4. Разреши показ поверх других окон."
            )
            .setPositiveButton("Автозапуск") { _, _ -> Emui.openAutoStart(this) }
            .setNeutralButton("Батарея") { _, _ -> Emui.openBattery(this) }
            .setNegativeButton("Закрыть", null).show()
    }

    // ---------- оверлей ----------
    private fun toggleOverlay() {
        val s = vm.state.value ?: return
        if (s.overlayOn) {
            vm.setOverlay(false)
            stopService(Intent(this, OverlayService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Разреши «Поверх других окон» для этого приложения и вернись назад")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startOverlay()
    }

    private fun startOverlay() {
        vm.setOverlay(true)
        startOverlayService()
        toast("Хомяк вышел на рабочий стол")
        moveTaskToBack(true)
    }

    private fun startOverlayService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        } catch (e: Exception) {
            toast("Не удалось запустить сервис оверлея")
        }
    }

    /** Если оверлей уже запущен: сервис перечитает клонов и одежду. */
    private fun syncOverlay() {
        if (vm.state.value?.overlayOn == true) startOverlayService()
    }
}
