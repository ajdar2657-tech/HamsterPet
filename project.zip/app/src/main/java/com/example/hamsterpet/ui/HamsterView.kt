package com.example.hamsterpet.ui

import android.content.Context
import android.graphics.Canvas
import android.view.View
import com.example.hamsterpet.data.Look

/** Один View и для приложения, и для оверлея. */
class HamsterView(ctx: Context) : View(ctx) {
    var color = Look.COLORS[0]
    var hat = 0
    var glasses = 0
    var happy = true
    var sleeping = false
    var frame = 0
    var faceRight = true

    fun set(color: Int, hat: Int, glasses: Int, happy: Boolean) {
        this.color = color; this.hat = hat; this.glasses = glasses; this.happy = happy
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        HamsterPainter.draw(
            canvas, minOf(width, height).toFloat(), color, hat, glasses,
            happy, sleeping, frame, faceRight
        )
    }
}
