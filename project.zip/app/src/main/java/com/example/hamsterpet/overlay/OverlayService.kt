package com.example.hamsterpet.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.hamsterpet.MainActivity
import com.example.hamsterpet.R
import com.example.hamsterpet.data.HamsterRepository
import com.example.hamsterpet.data.HamsterState
import com.example.hamsterpet.ui.HamsterView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * Foreground-сервис: каждый хомяк (главный + клоны) это маленькое окно TYPE_APPLICATION_OVERLAY.
 * Экономия батареи: нет постоянных циклов, ValueAnimator работает только во время ходьбы,
 * при выключенном экране всё останавливается.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.hamsterpet.STOP"
        private const val CH = "overlay"
        private const val SPEED_DP = 70f
    }

    private lateinit var wm: WindowManager
    private lateinit var repo: HamsterRepository
    private val handler = Handler(Looper.getMainLooper())
    private val pets = ArrayList<Pet>()
    private var menu: View? = null
    private var menuPet: Pet? = null
    private val hideMenuRun = Runnable { hideMenu() }
    private var screenOn = true
    private var receiverOn = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) {
                screenOn = false
                hideMenu()
                pets.forEach { it.pause() }
            } else {
                screenOn = true
                pets.forEach { it.resume() }
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        repo = HamsterRepository(this)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverOn = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            repo.update { it.copy(overlayOn = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        val s = repo.load()
        if (s == null || !s.overlayOn || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        sync(s)
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        pets.forEach { it.clamp() }
    }

    override fun onDestroy() {
        hideMenu()
        pets.forEach { it.remove() }
        pets.clear()
        if (receiverOn) {
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
            receiverOn = false
        }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------- уведомление ----------
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Хомяк на рабочем столе", NotificationManager.IMPORTANCE_MIN)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_hamster)
            .setContentTitle("Хомяк на рабочем столе")
            .setContentText("Нажми, чтобы открыть приложение")
            .setContentIntent(openPi)
            .addAction(0, "Убрать", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    // ---------- хомяки ----------
    private fun sync(s: HamsterState) {
        if (pets.none { it.isMain }) pets.add(Pet(true).also { it.add() })
        val want = 1 + s.clones
        while (pets.size < want) pets.add(Pet(false).also { it.add() })
        while (pets.size > want) pets.removeAt(pets.lastIndex).remove()
        pets.forEach { it.view.set(s.color, s.hat, s.glasses, s.mood >= 40f) }
    }

    /** [maxX, minY, maxY] допустимой области для левого-верхнего угла окна */
    private fun bounds(size: Int): IntArray {
        val m = resources.displayMetrics
        val minY = dp(24)
        return intArrayOf(
            (m.widthPixels - size).coerceAtLeast(0),
            minY,
            (m.heightPixels - size - dp(48)).coerceAtLeast(minY)
        )
    }

    private inner class Pet(val isMain: Boolean) {
        val size = dp(if (isMain) 72 else 60)
        val view = HamsterView(this@OverlayService)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        private var anim: ValueAnimator? = null
        private var paused = false
        private var removed = false
        private val next = Runnable { act() }

        fun add() {
            val b = bounds(size)
            lp.x = Random.nextInt(b[0] + 1)
            lp.y = b[1] + Random.nextInt(b[2] - b[1] + 1)
            view.setOnClickListener { showMenu(this) }
            try {
                wm.addView(view, lp)
            } catch (e: Exception) {
                removed = true
                stopSelf()
                return
            }
            schedule(600)
        }

        fun schedule(ms: Long) {
            if (paused || removed) return
            handler.removeCallbacks(next)
            handler.postDelayed(next, ms)
        }

        fun pause() {
            paused = true
            handler.removeCallbacks(next)
            anim?.cancel()
        }

        fun resume() {
            if (removed || !screenOn) return
            paused = false
            schedule(300)
        }

        fun remove() {
            removed = true
            handler.removeCallbacks(next)
            anim?.cancel()
            try { wm.removeView(view) } catch (e: Exception) {}
        }

        fun update() {
            try { wm.updateViewLayout(view, lp) } catch (e: Exception) {}
        }

        fun clamp() {
            val b = bounds(size)
            lp.x = lp.x.coerceIn(0, b[0])
            lp.y = lp.y.coerceIn(b[1], b[2])
            update()
        }

        private fun act() {
            if (paused || removed) return
            if (anim?.isRunning == true) { schedule(500); return }
            view.sleeping = false
            when (Random.nextInt(100)) {
                in 0..54 -> walk()
                in 55..74 -> { view.frame = 0; view.invalidate(); schedule(1500L + Random.nextInt(2500)) }
                in 75..89 -> { view.sleeping = true; view.invalidate(); schedule(6000L + Random.nextInt(6000)) }
                else -> hop(3)
            }
        }

        private fun walk() {
            val b = bounds(size)
            val atEdge = Random.nextInt(100) < 35
            val tx = if (atEdge) (if (Random.nextBoolean()) 0 else b[0]) else Random.nextInt(b[0] + 1)
            val ty = b[1] + Random.nextInt(b[2] - b[1] + 1)
            val sx = lp.x
            val sy = lp.y
            val dist = hypot((tx - sx).toFloat(), (ty - sy).toFloat())
            if (dist < size / 2f) { schedule(800); return }
            view.faceRight = tx >= sx
            val dur = (dist / (SPEED_DP * resources.displayMetrics.density) * 1000f).toLong().coerceAtLeast(300L)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = dur
                interpolator = LinearInterpolator()
                addUpdateListener { a ->
                    val f = a.animatedFraction
                    val nx = (sx + (tx - sx) * f).toInt()
                    val ny = (sy + (ty - sy) * f).toInt()
                    val fr = ((a.currentPlayTime / 160L) % 2).toInt()
                    if (abs(nx - lp.x) >= 2 || abs(ny - lp.y) >= 2) {
                        lp.x = nx; lp.y = ny; update()
                    }
                    if (fr != view.frame) { view.frame = fr; view.invalidate() }
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) {
                        view.frame = 0; view.invalidate()
                        schedule(if (atEdge) 2500L + Random.nextInt(3000) else 400L + Random.nextInt(1200))
                    }
                })
                start()
            }
        }

        fun hop(times: Int) {
            anim?.cancel()
            handler.removeCallbacks(next)
            val sy = lp.y
            val h = size * 0.4f
            view.happy = true; view.frame = 1; view.invalidate()
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 420L * times
                interpolator = LinearInterpolator()
                addUpdateListener {
                    val f = it.animatedFraction
                    val ny = (sy - h * abs(sin(PI.toFloat() * times * f))).toInt().coerceAtLeast(0)
                    if (ny != lp.y) { lp.y = ny; update() }
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) {
                        lp.y = sy; update()
                        view.frame = 0; view.invalidate()
                        schedule(1000)
                    }
                })
                start()
            }
        }
    }

    // ---------- мини-меню ----------
    private fun item(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(0xFF222222.toInt())
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

    private fun showMenu(p: Pet) {
        hideMenu()
        p.pause()
        p.view.sleeping = false
        p.view.invalidate()
        menuPet = p

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xF2FFFFFF.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0x33000000)
            }
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) { hideMenu(); true } else false
            }
        }
        box.addView(item("Покормить") { feed(p); hideMenu() })
        box.addView(item("Убрать с экрана") { removePet(p); hideMenu() })
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = box.measuredWidth
        val h = box.measuredHeight
        val m = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (p.lp.x + p.size / 2 - w / 2).coerceIn(0, (m.widthPixels - w).coerceAtLeast(0))
            y = if (p.lp.y > h + dp(8)) p.lp.y - h - dp(4) else p.lp.y + p.size + dp(4)
        }
        try {
            wm.addView(box, lp)
            menu = box
            handler.postDelayed(hideMenuRun, 6000)
        } catch (e: Exception) {
            menuPet = null
            p.resume()
        }
    }

    private fun hideMenu() {
        handler.removeCallbacks(hideMenuRun)
        menu?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        menu = null
        menuPet?.resume()
        menuPet = null
    }

    private fun feed(p: Pet) {
        if (p.isMain) {
            repo.update { it.feed() }
            Toast.makeText(this, "Ням!", Toast.LENGTH_SHORT).show()
        }
        p.hop(2)
    }

    private fun removePet(p: Pet) {
        if (p.isMain) {
            repo.update { it.copy(overlayOn = false) }
            stopSelf()
        } else {
            pets.remove(p)
            p.remove()
        }
    }
}
