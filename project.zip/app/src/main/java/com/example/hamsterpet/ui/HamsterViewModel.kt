package com.example.hamsterpet.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.hamsterpet.data.HamsterRepository
import com.example.hamsterpet.data.HamsterState
import com.example.hamsterpet.data.pct

class HamsterViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = HamsterRepository(app)
    private val _state = MutableLiveData<HamsterState?>()
    val state: LiveData<HamsterState?> = _state

    init { refresh() }

    fun refresh() { _state.value = repo.load() }

    fun create(name: String, color: Int) {
        repo.create(name.trim().ifBlank { "Хомяк" }.take(16), color)
        refresh()
    }

    fun feed() = act { it.feed() }
    fun water() = act { it.water() }

    /** false, если хомяк слишком голоден или хочет пить */
    fun play(): Boolean {
        val s = _state.value ?: return false
        if (s.hunger < 10f || s.thirst < 10f) return false
        act { it.played() }
        return true
    }

    fun setHat(i: Int) = act { it.copy(hat = i) }
    fun setGlasses(i: Int) = act { it.copy(glasses = i) }

    fun createClone() = act {
        if (it.canClone) it.copy(clones = it.clones + 1, hunger = (it.hunger - 15f).pct()) else it
    }

    fun deleteClones() = act { it.copy(clones = 0) }
    fun setOverlay(on: Boolean) = act { it.copy(overlayOn = on) }

    fun deleteHamster() {
        repo.delete()
        refresh()
    }

    private fun act(f: (HamsterState) -> HamsterState) {
        repo.update(f)
        refresh()
    }
}
