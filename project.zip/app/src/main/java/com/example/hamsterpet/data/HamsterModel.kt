package com.example.hamsterpet.data

import android.content.Context
import android.content.SharedPreferences

fun Float.pct(): Float = coerceIn(0f, 100f)

object Look {
    val COLORS = intArrayOf(
        0xFFD9A066.toInt(), 0xFFB0B0B8.toInt(), 0xFFF5EBDD.toInt(),
        0xFF8B5A2B.toInt(), 0xFF5C5C66.toInt()
    )
    val HATS = arrayOf("Без шляпы", "Кепка", "Колпак", "Корона")
    val GLASSES = arrayOf("Без очков", "Круглые", "Тёмные")
}

data class HamsterState(
    val name: String,
    val color: Int,
    val hunger: Float = 80f,
    val thirst: Float = 80f,
    val mood: Float = 80f,
    val hat: Int = 0,
    val glasses: Int = 0,
    val clones: Int = 0,
    val overlayOn: Boolean = false,
    val last: Long = System.currentTimeMillis()
) {
    val canClone: Boolean
        get() = hunger >= 70f && thirst >= 70f && mood >= 70f && clones < MAX_CLONES

    fun feed() = copy(hunger = (hunger + 30f).pct(), mood = (mood + 2f).pct())
    fun water() = copy(thirst = (thirst + 30f).pct(), mood = (mood + 2f).pct())
    fun played() = copy(mood = (mood + 25f).pct(), hunger = (hunger - 8f).pct(), thirst = (thirst - 8f).pct())

    companion object {
        const val MAX_CLONES = 5
    }
}

/** Все данные в SharedPreferences. Показатели считаются по времени (без фоновых таймеров). */
class HamsterRepository(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("hamster", Context.MODE_PRIVATE)

    fun load(): HamsterState? {
        if (!sp.getBoolean("exists", false)) return null
        val s = HamsterState(
            name = sp.getString("name", "Хомяк") ?: "Хомяк",
            color = sp.getInt("color", Look.COLORS[0]),
            hunger = sp.getFloat("hunger", 80f),
            thirst = sp.getFloat("thirst", 80f),
            mood = sp.getFloat("mood", 80f),
            hat = sp.getInt("hat", 0),
            glasses = sp.getInt("glasses", 0),
            clones = sp.getInt("clones", 0),
            overlayOn = sp.getBoolean("overlay", false),
            last = sp.getLong("last", System.currentTimeMillis())
        )
        return decay(s)
    }

    private fun decay(s: HamsterState): HamsterState {
        val min = ((System.currentTimeMillis() - s.last) / 60000f).coerceIn(0f, 2880f)
        val needy = s.hunger < 30f || s.thirst < 30f
        return s.copy(
            hunger = (s.hunger - 0.4f * min).pct(),
            thirst = (s.thirst - 0.6f * min).pct(),
            mood = (s.mood - (if (needy) 0.6f else 0.3f) * min).pct()
        )
    }

    private fun save(s: HamsterState) {
        sp.edit()
            .putBoolean("exists", true)
            .putString("name", s.name)
            .putInt("color", s.color)
            .putFloat("hunger", s.hunger)
            .putFloat("thirst", s.thirst)
            .putFloat("mood", s.mood)
            .putInt("hat", s.hat)
            .putInt("glasses", s.glasses)
            .putInt("clones", s.clones)
            .putBoolean("overlay", s.overlayOn)
            .putLong("last", System.currentTimeMillis())
            .apply()
    }

    fun create(name: String, color: Int) = save(HamsterState(name = name, color = color))

    fun delete() {
        sp.edit().clear().apply()
    }

    fun update(f: (HamsterState) -> HamsterState): HamsterState? {
        val s = load() ?: return null
        val n = f(s)
        save(n)
        return n
    }
}
